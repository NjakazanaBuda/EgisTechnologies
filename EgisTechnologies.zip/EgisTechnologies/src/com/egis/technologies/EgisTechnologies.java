package com.egis.technologies;


import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.File;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.gson.Gson;


public class EgisTechnologies {
	
	private static Logger logger = Logger.getLogger(EgisTechnologies.class);
	private static Properties prop;
	static Document doc;
	
	// loading properties file from a static block
	static{
        	try {
        			prop = new Properties();
        			prop.load(new FileInputStream("C:\\Personal\\App\\EgisTechnologies\\gistechnologies.properties")); // Path to properties file. This path must exist on the machine/server where the application is running.
        		} catch (Exception e){
        			e.printStackTrace();
        			logger.error("Error Message: " + e.getMessage());
        		}
        	}

    public static void main(String[] args) {
   
		List<String> alltechnologies = Collections.synchronizedList(new ArrayList<String>());
		
		alltechnologies.addAll(getProgrammingStack());
		alltechnologies.addAll(getBuildStack());
		alltechnologies.addAll(getInfrastructure());
		alltechnologies.removeAll(Collections.singleton(""));
			
		String json = new Gson().toJson(alltechnologies); //convert java list into json.
		System.out.println(json); // printing to console.
		
		File fileP = new File(getPropertyValue("filePath")); //declaring an instance of a file and getting the value or(path to a file) which is on properties file(gistechnologies.properties) using method or function getPropertyValue(String key). You can change the value or path on the properties file.
		try  
		{
			if (fileP.exists())
			{
				FileWriter file = new FileWriter(getPropertyValue("filePath")); //declaring an instance of a filewriter and getting the value from properties file. 
				file.write(json); //saving  list of technologies into a file"
				System.out.println("Successfully saving to File...");
				file.flush();
			}
			else{System.out.println("File or File path doesn't exist please creat it");}

        } catch (Exception e) {
            e.printStackTrace();
			logger.error("Error Message: " + e.getMessage());
        }

    }
    
    public static List<String> getProgrammingStack(){
        
    	 List<String> programmingstack = Collections.synchronizedList(new ArrayList<String>());
       
        	doc  = getConnection();
            	Elements div = doc.select("div[class*=readme blob instapaper_body]"); //checking for div with class readme blob instapaper_body.
            	Element table = div.select("table").get(0); //within the div mentioned above select the first table.
            
                for (Element tablerow : table.select("tr")) 
                {
                    Elements tabletds = tablerow.select("td");
                    if (tabletds.size() > 0) 
                    {
            
                    	programmingstack.add(tabletds.get(0).text());
                    }
                }
            
        return programmingstack;
    }
    
    public static List<String> getBuildStack(){
       
        List<String> buildstack = Collections.synchronizedList(new ArrayList<String>());
        	
        		doc  = getConnection();
        		
            	Elements div = doc.select("div[class*=readme blob instapaper_body]"); //checking for div with class readme blob instapaper_body.
            	Element table = div.select("table").get(1); //within the div mentioned above select the second table.
            
                for (Element tablerow : table.select("tr")) 
                {
                    Elements tabletds = tablerow.select("td");
                    if (tabletds.size() > 0) 
                    {
            
                    	buildstack.add(tabletds.get(0).text());
                    }
                }
       
        return buildstack;
    }
    
    public static List<String> getInfrastructure(){
    	
    	List<String> infrastructure = Collections.synchronizedList(new ArrayList<String>());
        
        		doc  = getConnection();
        		
            	Elements div = doc.select("div[class*=readme blob instapaper_body]"); //checking for div with class readme blob instapaper_body.
            	Element table = div.select("table").get(2); //within the div mentioned above select the third table.
            
                for (Element tablerow : table.select("tr")) 
                {
                    Elements tabletds = tablerow.select("td");
                    if (tabletds.size() > 0) 
                    {
            
                    	infrastructure.add(tabletds.get(0).text());
                    }
                }
           
        return infrastructure;
    }

    public static Document getConnection(){
       
      try {
        	
            	doc = Jsoup.connect(getPropertyValue("url")).get(); // parse website page.
            	
            
      } catch (Exception e) {
          e.printStackTrace();
			logger.error("Error Message: " + e.getMessage());
      }
       
        return doc;
    }

    public static String getPropertyValue(String key){
        return prop.getProperty(key);
    }


}